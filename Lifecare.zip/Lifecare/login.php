<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="login.css">
    <title>Login Page</title>
</head>
<body>
    
    <div class="login-container">
        <form action="life_care.php" method="post">
        <h1 class= "life">Clinical Trials</h1>
            <h2>Login</h2>
            <label for="user_type">User Type:</label>
            <select name="user_type" id="user_type">
                <option value="Researcher">Researcher</option>
                <option value="Doctor">Doctor</option>
                <option value="ClinicalMonitor">Clinical Monitor</option>
                <option value="Agencies">Regulatory Agencies</option>
                <option value="Statistician">Demographer</option>
            </select>
            <label for="password">Password:</label>
            <input type="password" name="password" required>
            <button type="submit">Login</button>
        </form>
    </div>
</body>
</html>