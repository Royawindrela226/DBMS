<?php
// Connect to your database
$servername = "localhost";
$username = "your_username";
$password = "your_password";
$database = "your_database";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve user inputs
    $user_type = $_POST["user_type"];
    $password = $_POST["password"];

    // Check if the password matches the predefined value
    $predefined_passwords = [
        "Researcher" => "researcher_password",
        "Doctor" => "doctor_password",
        "ClinicalMonitor" => "monitor_password",
        "Agencies" => "agencies_password",
        "Statistician" => "statistician_password"
    ];

    if (array_key_exists($user_type, $predefined_passwords) && $password === $predefined_passwords[$user_type]) {
        echo "Login successful!";
        // You can redirect the user to another page or perform additional actions here
    } else {
        echo "Invalid username or password";
    }
}

$conn->close();
?>